# Samples — ready to open, no run required

Pre-rendered with sample data so you can see the two reports immediately.
Open the HTML files in any modern browser; open the workbooks in Excel.

| File | Report |
|------|--------|
| `Metrics_Dashboard_SDLC.html` | SDLC register — Overview · Rankings · Coverage |
| `Metrics_Dashboard_Northstar.html` | Northstar (Plandek) — Overview · Rankings · Coverage |
| `Metrics_SDLC_Register.xlsx` | SDLC register workbook (Metrics · Reference · Coverage · Agent Reference) |
| `Metrics_Northstar_Plandek.xlsx` | Northstar workbook (Northstar Framework · Open Items) |

A real run (`/metrics-setup` then `/metrics-refresh both`) regenerates fresh dashboards
into `dashboards/dashboard-<set>.html` using live data; these samples are not overwritten.
