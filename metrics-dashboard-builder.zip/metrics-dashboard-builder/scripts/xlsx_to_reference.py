#!/usr/bin/env python3
"""Regenerate the two reference sets from the workbook, kept separate so each
requirement set can be updated independently:

  skills/metric-collection/reference/metric-reference.json     <- 'Metrics' + 'Agent Reference' tabs  (set: SDLC register)
  skills/metric-collection/reference/northstar-reference.json  <- 'Northstar Framework' tab           (set: Northstar (Plandek))

Usage:  xlsx_to_reference.py path/to/Metrics_SDLC_Map_SoftServe.xlsx
Requires: openpyxl
"""
import sys, os, json
import openpyxl

PMAP = {'Trend line': 'trend', 'Gauge / %': 'gauge', 'Likert / gauge': 'gauge',
        'KPI tile': 'kpi', 'Number': 'kpi', 'KPI tile+Trend line': 'kpi',
        'Bar chart': 'bar', 'Stacked bar': 'stacked'}
REFDIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                      'skills', 'metric-collection', 'reference')


def stype(s):
    s = (s or '').lower()
    if 'external' in s: return 'external'
    if 'sonar' in s: return 'static'
    if 'pipeline' in s: return 'pipeline'
    if 'repos' in s or 'bitbucket' in s or 'pr api' in s or 'git' in s: return 'vcs'
    if 'confluence' in s: return 'confluence'
    if 'xray' in s or 'zephyr' in s or 'test plans' in s: return 'test'
    return 'jira'


def hdrmap(ws, maxr=8, maxc=15):
    for r in range(1, maxr):
        vals = [ws.cell(r, c).value for c in range(1, maxc)]
        if 'Metric' in vals:
            return r, {ws.cell(r, c).value: c for c in range(1, maxc) if ws.cell(r, c).value}
    raise SystemExit("no header row with 'Metric'")


def col(h, name):
    for k in h:
        if k and k.strip().lower().startswith(name.lower()):
            return h[k]
    return None


def build_sdlc(wb):
    ms, ar = wb['Metrics'], wb['Agent Reference']
    mhr, mh = hdrmap(ms); ahr, ah = hdrmap(ar)
    arows = {}
    for r in range(ahr + 1, ar.max_row + 1):
        n = ar.cell(r, ah['Metric']).value
        if not n: continue
        arows[n] = {'source_system': ar.cell(r, ah['Source system']).value,
                    'mcp': ar.cell(r, ah['MCP / connector']).value,
                    'object': ar.cell(r, ah['Object / data']).value,
                    'fields': ar.cell(r, ah['Key fields & metadata']).value,
                    'query': ar.cell(r, ah['Query / keyword hints']).value,
                    'derivation': ar.cell(r, ah['Derivation']).value}
    metrics = []
    for r in range(mhr + 1, ms.max_row + 1):
        n = ms.cell(r, mh['Metric']).value
        if not n: continue
        a = arows.get(n, {}); syss = a.get('source_system', '')
        pres = ms.cell(r, mh['Presentation']).value or 'Number'
        metrics.append({'name': n, 'set': 'SDLC register', 'set_id': 'sdlc-register',
            'category': ms.cell(r, mh['Category']).value, 'group': ms.cell(r, mh['Group']).value,
            'owner': ms.cell(r, mh['Owner']).value, 'sdlc_stage': ms.cell(r, mh['SDLC stage']).value,
            'level': ms.cell(r, mh['Level']).value, 'parent': ms.cell(r, mh['Parent metric']).value,
            'presentation': pres, 'widget': PMAP.get(pres, 'kpi'), 'formula': ms.cell(r, mh['Formula']).value,
            'source_system': syss, 'source_type': stype(syss), 'mcp': a.get('mcp'), 'object': a.get('object'),
            'fields': a.get('fields'), 'query': a.get('query'), 'derivation': a.get('derivation'),
            'external': stype(syss) == 'external'})
    return {'version': '1.1.0', 'set': 'SDLC register', 'set_id': 'sdlc-register',
            'note': "Original SDLC metrics register (tool-agnostic). Update from the 'Metrics' + 'Agent Reference' tabs. Independent of the Northstar set.",
            'presentation_to_widget': PMAP, 'categories': ['Time-to-Market', 'Role Performance', 'AI Adoption'],
            'metrics': metrics}


def build_northstar(wb):
    ns = wb['Northstar Framework']; hr, h = hdrmap(ns)
    def stat(v):
        v = v or ''
        return 'now' if 'Now' in v else 'partial' if 'Partial' in v else 'gap' if 'Gap' in v else 'unknown'
    metrics = []
    for r in range(hr + 1, ns.max_row + 1):
        n = ns.cell(r, col(h, 'Metric')).value
        if not n: continue
        src = ns.cell(r, col(h, 'Data source')).value or ''
        metrics.append({'name': n, 'set': 'Northstar (Plandek)', 'set_id': 'northstar-plandek',
            'pillar': ns.cell(r, col(h, 'Pillar')).value, 'definition': ns.cell(r, col(h, 'Definition')).value,
            'formula': ns.cell(r, col(h, 'Formula')).value, 'data_source': src, 'source_type': stype(src),
            'status': stat(ns.cell(r, col(h, 'Status')).value), 'access_item': ns.cell(r, col(h, 'Access')).value,
            'benchmark_ai_top': ns.cell(r, col(h, 'Top quartile')).value,
            'in_our_solution': ns.cell(r, col(h, 'In our solution')).value, 'external': stype(src) == 'external'})
    return {'version': '1.0.0', 'set': 'Northstar (Plandek)', 'set_id': 'northstar-plandek',
            'note': "Sponsor reference standard - Plandek four-pillar framework + AI overlay. Update from the 'Northstar Framework' tab. Benchmarks are AI-team top quartile, reference only.",
            'pillars': ['Focus', 'Speed', 'Predictability', 'Quality', 'AI Overlay'], 'metrics': metrics}


def main():
    if len(sys.argv) < 2:
        sys.exit("usage: xlsx_to_reference.py <workbook.xlsx>")
    wb = openpyxl.load_workbook(sys.argv[1])
    sdlc = build_sdlc(wb)
    json.dump(sdlc, open(os.path.join(REFDIR, 'metric-reference.json'), 'w'), indent=2, ensure_ascii=False)
    print("wrote metric-reference.json   (%d metrics, set: SDLC register)" % len(sdlc['metrics']))
    if 'Northstar Framework' in wb.sheetnames:
        ns = build_northstar(wb)
        json.dump(ns, open(os.path.join(REFDIR, 'northstar-reference.json'), 'w'), indent=2, ensure_ascii=False)
        print("wrote northstar-reference.json (%d metrics, set: Northstar (Plandek))" % len(ns['metrics']))


if __name__ == '__main__':
    main()
