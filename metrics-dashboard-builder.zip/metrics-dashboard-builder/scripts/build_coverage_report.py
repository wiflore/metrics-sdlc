#!/usr/bin/env python3
"""Generate per-set coverage-report.md - a gap report in the style of the sponsor's
Northstar alignment doc. Each requirement set is reported on its own.

Layout:
  reference/metric-reference.json      (sdlc)        + .metrics/sdlc/metrics-data.json      -> .metrics/sdlc/coverage-report.md
  reference/northstar-reference.json   (northstar)   + .metrics/northstar/metrics-data.json -> .metrics/northstar/coverage-report.md
  .metrics/metric-map.json is shared (entries tagged by set).

Usage:
  build_coverage_report.py --set both        # default
  build_coverage_report.py --set northstar
"""
import argparse, json, os, re, datetime

ROOT = os.environ.get("CLAUDE_PLUGIN_ROOT", os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DEF_REFS = os.path.join(ROOT, "skills", "metric-collection", "reference")
GREEN, AMBER, RED = "\U0001F7E2", "\U0001F7E1", "\U0001F534"
SETS = {
    "sdlc":      {"ref": "metric-reference.json",    "label": "SDLC register"},
    "northstar": {"ref": "northstar-reference.json", "label": "Northstar (Plandek)"},
}
ACCESS = {
    "A": "Jira read access beyond labels (issue types, statuses, links, timestamps)",
    "B": "Production/deploy signal (a Jira 'in production' status or a deploy log)",
    "C": "Sprint-board data (commitments, completion, scope-change, velocity history)",
    "D": "PR-API access (Bitbucket for legacy repos, Azure DevOps for the current repo)",
    "E": "Exact formula (proposed: delivered / (cycle time x #devs))",
    "F": "Definition (Velocity Volatility = CV; Abandoned PR = closed-unmerged / opened)",
    "G": "Bug->origin linkage (a 'caused-by' / 'found-in' field or link)",
    "H": "Set own targets/baseline (do not adopt the deck's quartile benchmarks)",
    "I": "Confirm BA denominator + Testing-Task scenario format",
}


def load(p):
    try:
        return json.load(open(p, encoding="utf-8"))
    except Exception:
        return None


def needed_from_access(access):
    if not access:
        return ""
    letters = re.findall(r"\b([A-I])\b", str(access))
    parts = [ACCESS[l] for l in dict.fromkeys(letters) if l in ACCESS]
    if "commit" in str(access).lower() or "branch" in str(access).lower():
        parts.append("ticket-key in commit/branch")
    return " ; ".join(parts) if parts else str(access)


def status_for(metric, mp_entry, data_names, stale_names, val_crit):
    name = metric["name"]
    if name in data_names:
        if name in stale_names:
            return AMBER, "Stale", "source failed this run; previous value kept", "re-run / restore source access"
        if name in val_crit:
            return RED, "Invalid", "failed validation", "fix formula/data, re-collect"
        return GREEN, "Collected", "collected this run", ""
    if mp_entry is not None and mp_entry.get("enabled") is False:
        reason = mp_entry.get("reason", "disabled / unmapped")
        if metric.get("external"):
            return RED, "External", reason, "vendor analytics export or survey"
        return RED, "Unmapped", reason, "resolve in /metrics-setup"
    if metric.get("set_id") == "northstar-plandek":
        st = metric.get("status"); needed = needed_from_access(metric.get("access_item"))
        if st == "now":     return GREEN, "Ready", "measurable now", needed
        if st == "partial": return AMBER, "Partial", "definition known; data access needed", needed
        if st == "gap":     return RED, "Gap", "access or definition missing", needed
        return AMBER, "Pending", "awaiting first collection", needed
    if metric.get("external"):
        return RED, "External", "AI-tool analytics / survey - not in the MCPs", "vendor analytics export or survey"
    return AMBER, "Pending", "awaiting first collection", ""


def render_set(ref, mp, data_names, stale_names, val_crit):
    metrics = ref.get("metrics", [])
    gk = "pillar" if ref.get("set_id") == "northstar-plandek" else "category"
    groups, counts = {}, {GREEN: 0, AMBER: 0, RED: 0}
    for m in metrics:
        mp_entry = (mp or {}).get("metrics", {}).get(m["name"]) if mp else None
        emoji, label, reason, needed = status_for(m, mp_entry, data_names, stale_names, val_crit)
        counts[emoji] += 1
        groups.setdefault(m.get(gk) or "Other", []).append((m, emoji, label, reason, needed))
    lines = [f"## {ref.get('set','(set)')}  \n",
             f"_{counts[GREEN]} {GREEN} ready/collected \u00b7 {counts[AMBER]} {AMBER} partial/pending \u00b7 {counts[RED]} {RED} gap/external_\n"]
    for g, rows in groups.items():
        lines.append(f"\n### {g}\n")
        lines.append("| Metric | Status | Reason | What's needed | Owner |")
        lines.append("|---|---|---|---|---|")
        for m, emoji, label, reason, needed in rows:
            lines.append(f"| {m['name']} | {emoji} {label} | {reason} | {needed} | {m.get('owner') or ''} |")
    return "\n".join(lines), counts


def run_one(set_id, refs_dir, metrics_dir):
    cfg = SETS[set_id]
    ref = load(os.path.join(refs_dir, cfg["ref"]))
    if not ref:
        print(f"[{cfg['label']}] reference missing - skipped"); return
    set_dir = os.path.join(metrics_dir, set_id)
    mp = load(os.path.join(metrics_dir, "metric-map.json"))
    data = load(os.path.join(set_dir, "metrics-data.json"))
    val = load(os.path.join(set_dir, "validation-report.json"))
    data_names = {m.get("name") for m in (data or {}).get("metrics", [])} if data else set()
    stale_names = {m.get("name") for m in (data or {}).get("metrics", []) if m.get("stale")} if data else set()
    val_crit = {c.get("metric") for c in (val or {}).get("critical", [])} if val else set()
    phase = "post-run" if data else ("post-discovery" if mp else "planned (pre-run)")
    now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    body, counts = render_set(ref, mp, data_names, stale_names, val_crit)
    out = os.path.join(set_dir, "coverage-report.md")
    os.makedirs(set_dir, exist_ok=True)
    head = (f"# Coverage report - {cfg['label']}\n\n_Generated {now} \u00b7 {phase}._\n\n"
            f"**Totals:** {counts[GREEN]} {GREEN} \u00b7 {counts[AMBER]} {AMBER} \u00b7 {counts[RED]} {RED}\n\n"
            "Legend: \U0001F7E2 ready/collected \u00b7 \U0001F7E1 partial/pending \u00b7 \U0001F534 gap/external. "
            "Targets set from own baseline (deck quartiles are reference-only).\n\n")
    open(out, "w", encoding="utf-8").write(head + body + "\n")
    print(f"[{cfg['label']}] wrote {out}  ({phase})  {counts[GREEN]}/{counts[AMBER]}/{counts[RED]} G/A/R")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--set", choices=["sdlc", "northstar", "both"], default="both")
    ap.add_argument("--refs-dir", default=DEF_REFS)
    ap.add_argument("--metrics-dir", default=".metrics")
    a = ap.parse_args()
    targets = ["sdlc", "northstar"] if a.set == "both" else [a.set]
    for s in targets:
        run_one(s, a.refs_dir, a.metrics_dir)


if __name__ == "__main__":
    main()
