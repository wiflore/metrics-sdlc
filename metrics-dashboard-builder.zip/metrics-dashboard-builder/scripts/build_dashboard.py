#!/usr/bin/env python3
"""Render one or both report dashboards by injecting per-set data into the matching template.

Each requirement set has its own template and its own data folder:
  assets/dashboard-sdlc.template.html       <- .metrics/sdlc/metrics-data.json       -> dashboards/dashboard-sdlc.html
  assets/dashboard-northstar.template.html  <- .metrics/northstar/metrics-data.json  -> dashboards/dashboard-northstar.html

Usage:
  build_dashboard.py --set both                 # default: build both reports
  build_dashboard.py --set northstar            # build only the Northstar report
  build_dashboard.py --set sdlc --metrics-dir .metrics --out-dir dashboards
"""
import argparse, json, os, sys

ROOT = os.environ.get("CLAUDE_PLUGIN_ROOT", os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
MARKER_START = "/*__METRICS_JSON__*/"
MARKER_END = "/*__END__*/"
SETS = {
    "sdlc":      {"tpl": "dashboard-sdlc.template.html",      "label": "SDLC register"},
    "northstar": {"tpl": "dashboard-northstar.template.html", "label": "Northstar (Plandek)"},
}


def build_one(set_id, metrics_dir, out_dir):
    cfg = SETS[set_id]
    tpl_path = os.path.join(ROOT, "assets", cfg["tpl"])
    data_path = os.path.join(metrics_dir, set_id, "metrics-data.json")
    out_path = os.path.join(out_dir, f"dashboard-{set_id}.html")

    tpl = open(tpl_path, encoding="utf-8").read()
    if MARKER_START not in tpl:
        sys.exit(f"ERROR: {cfg['tpl']} missing injection marker {MARKER_START}")

    if os.path.exists(data_path):
        data = json.load(open(data_path, encoding="utf-8"))
        payload = json.dumps(data, ensure_ascii=False)
        note = f"{len(data.get('metrics', []))} metrics from {data_path}"
    else:
        payload = "null"
        note = f"no data ({data_path}) - built-in sample"

    pre = tpl.split(MARKER_START)[0]
    post = tpl.split(MARKER_END, 1)[1]
    html = pre + MARKER_START + " " + payload + " " + MARKER_END + post
    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    open(out_path, "w", encoding="utf-8").write(html)
    print(f"[{cfg['label']}] wrote {out_path} ({len(html)//1024} KB; {note})")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--set", choices=["sdlc", "northstar", "both"], default="both")
    ap.add_argument("--metrics-dir", default=".metrics")
    ap.add_argument("--out-dir", default="dashboards")
    a = ap.parse_args()
    targets = ["sdlc", "northstar"] if a.set == "both" else [a.set]
    for s in targets:
        build_one(s, a.metrics_dir, a.out_dir)


if __name__ == "__main__":
    main()
