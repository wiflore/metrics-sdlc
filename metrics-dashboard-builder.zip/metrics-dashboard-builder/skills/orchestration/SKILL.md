---
name: orchestration
description: >
  Run the metrics dashboard build as a multi-agent pipeline with quality gates.
  Use when the user runs /metrics-refresh or asks to build/rebuild the dashboard end to end.
  The main session is the orchestrator: it sequences discovery, parallel collection,
  validation, consolidation, rendering and review, enforcing a checkpoint between each phase.
---

# Orchestration

You (the main session) are the **orchestrator**. You do not collect or compute directly —
you sequence specialized subagents and enforce a **checkpoint** between phases. Subagents
cannot spawn other subagents, so all delegation happens from here.

**Two reports, run independently.** There are two requirement sets — `sdlc` and `northstar`
— each a separate report with its own data folder and output. The user can ask for one, the
other, or both (default both). Discovery and the learned map are **shared** (one map, every
entry tagged with its `set`); collection, validation, consolidation, build and review run
**per set**, writing under `.metrics/<set>/`. Repo entries also carry a `provider`
(`bitbucket` for legacy repos, `azure` for the current repo).

Read `${CLAUDE_PLUGIN_ROOT}/skills/metric-collection/SKILL.md` and `reference/schemas.md`
for the data model. Then run the pipeline (for each selected set):

```
[0 Preflight] → [1 Discovery] —A→ [2 Collect ‖] —B→ [3 Validate] —C→
[4 Consolidate] —D→ [5 Build] → [6 Review] —E→ done
```

`‖` = parallel.  `—X→` = checkpoint X must pass before proceeding.

## Phases & which agent runs each

| # | Phase | Runs | Output |
|---|-------|------|--------|
| 0 | Preflight | orchestrator | confirm MCPs connected; confirm `.metrics/metric-map.json` exists (else go to Discovery) |
| 1 | Discovery (first run / `--reset`) | orchestrator + `metric-collection` skill | `.metrics/metric-map.json`, `DISCOVERY.md` |
| 2 | Collection (parallel) | `jira-collector`, `confluence-collector`, `vcs-collector`, `pipeline-collector` | `.metrics/<set>/partials/<source>.json` each |
| 3 | Validation | `metrics-validator` | `.metrics/<set>/validation-report.json` |
| 4 | Consolidation | `metrics-consolidator` | `.metrics/<set>/metrics-data.json` (+ history, rankings) |
| 5 | Build | orchestrator runs `build_dashboard.py --set <set>` + `build_coverage_report.py --set <set>` | `dashboards/dashboard-<set>.html`, `.metrics/<set>/coverage-report.md` |
| 6 | Review | `metrics-reviewer` | `.metrics/<set>/review.md` + summary to user |

Phases 2–6 run per selected set; phases 0–1 (preflight + discovery + map) run once and are shared.

Launch the four collectors **in one batch (parallel)**, each scoped to the `enabled`
metrics for its source and given the `{since}` watermark from `state.json`.

## Checkpoints (gates — these are NOT subagents)

Each gate has automatic pass/fail criteria; **A and E are human-in-the-loop**.

- **A — Map confirmed.** After discovery, show the user the resolved fields/labels/units
  and any ambiguous choices. **Wait for the user to confirm or correct** before collecting.
  (Skip on incremental runs where the map already exists and is unchanged.)
- **B — Coverage.** Every expected source returned a partial; no collector hard-failed.
  If a source errored: keep its prior values, mark them `stale`, and continue *only* if the
  user is fine with a partial refresh — otherwise stop and report.
- **C — Validation.** No **critical** findings from `metrics-validator` (zero/negative
  denominators, unit mismatch, value outside sane range, formula≠derivation). Warnings may
  pass with annotation; criticals block — stop and report which metrics failed.
- **D — Integrity.** Consolidated `metrics-data.json` is schema-valid, every `enabled`
  metric is present, and each metric has the fields its `widget` needs
  (trend→`series`, gauge/kpi→`value`+`target`+`goal`, bar→`bars`, stacked→`seg`).
- **E — Sign-off.** For each set, present the reviewer's summary plus
  **`.metrics/<set>/coverage-report.md`** (the sponsor-style gap report: every metric in that
  set with 🟢/🟡/🔴, the reason, and what's needed). This is the user's final read before
  sharing `dashboards/dashboard-<set>.html`.

A failed gate **stops the pipeline** with a clear, specific report — never push past a gate
silently, and never fabricate values to satisfy one.

## Orchestrator rules

- Pass each subagent only the slice of context it needs (its source's map + reference rows,
  the watermark). Collect their returned/partial JSON; don't duplicate their work.
- On incremental runs, skip Discovery and Checkpoint A; go straight to Collection.
- Run the pipeline per selected set; emit one final summary **per set**: collected / unchanged
  / stale / skipped(external) / failed, gate results, and the `dashboards/dashboard-<set>.html` path.
- Everything is read-only against source systems. The only writers are the consolidator
  (`.metrics/<set>/metrics-data.json`), discovery (`metric-map.json`), and the build script (`dashboards/dashboard-<set>.html`).
