---
name: metric-collection
description: >
  Collect SDLC delivery, quality and AI-adoption metrics from Jira, Confluence,
  Bitbucket and Azure DevOps (via their MCP connectors) and shape them into the
  data the metrics dashboard renders. Use when the user wants to set up, discover,
  collect, refresh, or troubleshoot the metrics dashboard, or asks where a metric's
  data comes from. Handles first-run discovery (learning the org's concrete fields
  and conventions) and incremental re-collection that reuses prior runs.
---

# Metric collection

You turn a tool-agnostic **metric register** into a populated **dashboard** by
resolving where each metric lives in *this* organization, collecting it from the
right MCP, and computing it. You improve on every run: the first run learns the
mapping; later runs reuse it and only fetch what changed.

## The three files you rely on

1. **Two reference sets (read-only), kept in separate files so each requirement
   evolves independently — every metric carries a `set` / `set_id` tag:**
   - **`reference/metric-reference.json`** — `set: "SDLC register"` (`sdlc-register`).
     The original 65 metrics: category, group, owner, sdlc_stage, level, `widget`,
     formula, source system + `source_type`, fields, query hints. Update from the
     *Metrics* + *Agent Reference* workbook tabs.
   - **`reference/northstar-reference.json`** — `set: "Northstar (Plandek)"`
     (`northstar-plandek`). The sponsor four-pillar set + AI overlay: pillar,
     definition, formula, data_source, `status` (now/partial/gap), `access_item`
     (A–I), benchmark (AI-team top quartile, reference-only), and `in_our_solution`.
     Update from the *Northstar Framework* tab.
   Load **both**; never merge them — keep the `set` tag through collection, the
   coverage report, and the dashboard so each requirement is identifiable and
   updatable on its own. Regenerate with `scripts/xlsx_to_reference.py`.
2. **`.metrics/metric-map.json`** (project) — the *learned* concrete resolution
   (real custom-field IDs, status names, boards, repos, pipelines, label values,
   ranking units). Written by setup, reused by every collect.
3. **`.metrics/state.json`** (shared watermarks) and **`.metrics/<set>/metrics-data.json`**
   (project) — the incremental watermarks and the per-set collected dashboard data. The two
   sets (`sdlc`, `northstar`) are collected independently into their own folders; see
   `reference/schemas.md` §6 for the full layout.

Full shapes are in `reference/schemas.md` — read it before writing any of these files.

## Decide which phase you are in

- **No `.metrics/metric-map.json`** → run **Discovery** (see `/metrics-setup`).
  Never collect before a map exists; you would guess field IDs and produce wrong numbers.
- **Map exists** → run **Incremental collection** (see `/metrics-collect`).

## Discovery (first run) — learn the org, write the map

Goal: resolve every reference metric to concrete, queryable specifics, so future
runs are fast and correct. Work source-by-source using the connected MCPs:

- **Jira (Atlassian MCP):** list projects and boards; read the field metadata to find
  the **story-points**, **sprint**, **environment**, and **Definition-of-Ready** custom
  field IDs (don't assume `customfield_10026`); sample recent issues to learn the actual
  **status workflow names** (for changelog transitions) and how **prod vs non-prod
  defects** are distinguished (environment field value, a label like `prod-defect`, a
  component, or released `fixVersion`).
- **Confluence (Atlassian MCP):** find the spaces and the **labels** used for onboarding,
  glossary, persona, and definition-of-ready pages.
- **Bitbucket + Azure DevOps MCPs:** list the **workspace/org, project and repos** in scope,
  and tag each repo with its `provider` — **`bitbucket`** for legacy repos, **`azure`** for the
  current repo. Both providers feed the same VCS metrics; the collector queries each repo's own MCP.
- **Azure / Bitbucket Pipelines MCP:** identify the **release pipeline(s)** and the
  **environment** names used for production deploys.
- **Ranking units:** establish the org's **Teams**, **Business Units** and the
  team→BU mapping, and which board/repo belongs to each team (needed for rankings).

Then for each metric write a `metrics[<name>]` entry with `enabled`, `source`,
`widget`, `unit`, `goal`, `target`, optional `hero`, a concrete `collect` recipe
(with a `{since}` placeholder for incrementality), and `rankable` dimensions.

Rules:
- **Confirm ambiguity, don't guess.** When more than one field/label/status could be
  "the" one (e.g. two date fields, two "story point" fields, an unclear prod signal),
  ask the user a single grouped question and record the choice. Wrong guesses here
  poison every future run.
- **External metrics:** the 12 rows whose `source_type` is `external` (AI-tool analytics
  and surveys) are **not** in Jira/Confluence/Bitbucket/Azure. Set `enabled:false` with a
  `reason`. Offer the user the option to paste an export later, but never fabricate them.
- **Preserve user edits.** Targets, goals and `hero` flags the user has set must survive
  re-discovery — merge, don't overwrite.
- Write `.metrics/DISCOVERY.md`: what you resolved, what you assumed, what's unmapped,
  and the exact field IDs/labels — so a human can audit and correct it.

## Incremental collection (every later run) — reuse, then extend

1. Read `metric-map.json`, `state.json`, and the existing `metrics-data.json`.
2. For each `enabled` metric, run its `collect` recipe with `{since}` =
   `state.watermarks[<set>][source]`. Pull **only items changed since the watermark**.
   Point-in-time metrics (coverage, capacity, tech debt) are re-fetched at latest.
3. **Merge, don't replace:** update the affected metrics' current `value`/`delta`,
   append a new point to `history[<metric>]` for trend metrics, and recompute
   per-unit `rankings` values for the new period. Keep untouched metrics as-is.
4. Recompute `delta` as change vs the previous period from `history`.
5. Update `state.json` watermarks and append a run record. Write `metrics-data.json`.
6. Report a short summary: counts collected / unchanged / skipped(external) / failed,
   and anything newly ambiguous (offer to re-run discovery for just those).

If a source is unreachable or a query errors, keep the previous values for those
metrics, mark them stale in the summary, and continue — never zero them out.

## Computing metrics (use the reference's `derivation` + `formula`)

- **Durations** (lead/cycle/dev/test time): read the issue **changelog**; elapsed =
  later transition timestamp − earlier one, per `status_map`. Average across the sprint.
- **Counts / sums** (velocity, stories created, defects): JQL with the resolved fields;
  sum the story-points field for Done items.
- **Ratios / %** (defect leakage, coverage, review failure, DoR quality): numerator ÷
  denominator × 100; classify prod vs non-prod via the resolved `prod_signal`.
- **PR metrics** (review time, time-to-merge, failure rate, merge frequency): pull PRs from
  **both** providers — Bitbucket for legacy repos, Azure DevOps for the current repo — per each
  repo's `provider` in the map; normalize the two shapes, then approval-vs-created timestamps
  and count PRs with changes-requested/declined.
- **Pipeline metrics** (deployment time, CI coverage): pipeline run start/finish, result,
  coverage artifact.
- Carry `widget`, `unit`, `goal`, `target` from the map into each metric so the
  dashboard renders the correct widget and status.

## Rendering

Rendering is mechanical — run the build script (see `/metrics-dashboard`), which writes one
self-contained file per set into `dashboards/`:
`python3 ${CLAUDE_PLUGIN_ROOT}/scripts/build_dashboard.py --set sdlc|northstar|both`
It injects each set's data into its template and writes self-contained `dashboards/dashboard-<set>.html`.

## Guardrails

- Never invent numbers for `external` or failed metrics; show them as disabled/stale.
- Don't hardcode field IDs in the skill — they live in `metric-map.json`, per org.
- Respect MCP permissions; you are reading reporting data only — never modify source systems.
