# Coverage report - Northstar (Plandek)

_Generated 2026-06-25 23:12 UTC · planned (pre-run)._

**Totals:** 4 🟢 · 10 🟡 · 8 🔴

Legend: 🟢 ready/collected · 🟡 partial/pending · 🔴 gap/external. Targets set from own baseline (deck quartiles are reference-only).

## Northstar (Plandek)  

_4 🟢 ready/collected · 10 🟡 partial/pending · 8 🔴 gap/external_


### Focus

| Metric | Status | Reason | What's needed | Owner |
|---|---|---|---|---|
| Value Delivery % | 🟡 Partial | definition known; data access needed | Jira read access beyond labels (issue types, statuses, links, timestamps) |  |
| % Support & Maintenance | 🟡 Partial | definition known; data access needed | Jira read access beyond labels (issue types, statuses, links, timestamps) |  |

### Speed

| Metric | Status | Reason | What's needed | Owner |
|---|---|---|---|---|
| Lead Time to Value (days) | 🔴 Gap | access or definition missing | Production/deploy signal (a Jira 'in production' status or a deploy log) |  |
| Cycle Time (days) | 🟡 Partial | definition known; data access needed | Production/deploy signal (a Jira 'in production' status or a deploy log) |  |
| Time to Merge PRs (hours) | 🟡 Partial | definition known; data access needed | PR-API access (Bitbucket for legacy repos, Azure DevOps for the current repo) |  |
| Throughput Quotient | 🔴 Gap | access or definition missing | Exact formula (proposed: delivered / (cycle time x #devs)) ; Jira read access beyond labels (issue types, statuses, links, timestamps) ; PR-API access (Bitbucket for legacy repos, Azure DevOps for the current repo) |  |
| PR Efficiency Quotient | 🟡 Partial | definition known; data access needed | PR-API access (Bitbucket for legacy repos, Azure DevOps for the current repo) |  |
| Merge Frequency (/author weekly) | 🟢 Ready | measurable now | PR-API access (Bitbucket for legacy repos, Azure DevOps for the current repo) |  |

### Predictability

| Metric | Status | Reason | What's needed | Owner |
|---|---|---|---|---|
| Sprint Capacity Accuracy | 🔴 Gap | access or definition missing | Sprint-board data (commitments, completion, scope-change, velocity history) |  |
| Sprint Target Completion | 🔴 Gap | access or definition missing | Sprint-board data (commitments, completion, scope-change, velocity history) |  |
| Scope Change % | 🔴 Gap | access or definition missing | Sprint-board data (commitments, completion, scope-change, velocity history) |  |
| Velocity Volatility | 🔴 Gap | access or definition missing | Sprint-board data (commitments, completion, scope-change, velocity history) ; Definition (Velocity Volatility = CV; Abandoned PR = closed-unmerged / opened) |  |

### Quality

| Metric | Status | Reason | What's needed | Owner |
|---|---|---|---|---|
| Bug Resolution Time | 🟡 Partial | definition known; data access needed | Jira read access beyond labels (issue types, statuses, links, timestamps) |  |
| Stories Delivered : Bugs Raised | 🟡 Partial | definition known; data access needed | Bug->origin linkage (a 'caused-by' / 'found-in' field or link) |  |
| Bugs Resolved : Bugs Raised | 🟢 Ready | measurable now | Jira read access beyond labels (issue types, statuses, links, timestamps) |  |
| Abandoned PR rate | 🔴 Gap | access or definition missing | PR-API access (Bitbucket for legacy repos, Azure DevOps for the current repo) ; Definition (Velocity Volatility = CV; Abandoned PR = closed-unmerged / opened) |  |

### AI Overlay

| Metric | Status | Reason | What's needed | Owner |
|---|---|---|---|---|
| Share of AI-authored change | 🟢 Ready | measurable now | - |  |
| AI adoption breadth (Dev) | 🟢 Ready | measurable now | - |  |
| AI vs non-AI cycle time / Stories:Bugs | 🟡 Partial | definition known; data access needed | Bug->origin linkage (a 'caused-by' / 'found-in' field or link) |  |
| AI-assisted BA share | 🟡 Partial | definition known; data access needed | Confirm BA denominator + Testing-Task scenario format |  |
| AI-generated QA coverage | 🟡 Partial | definition known; data access needed | Confirm BA denominator + Testing-Task scenario format |  |
| Phase coverage map (BA→Dev→QA) | 🔴 Gap | access or definition missing | ticket-key in commit/branch |  |
