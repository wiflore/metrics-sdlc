# Coverage report - SDLC register

_Generated 2026-06-25 23:12 UTC · planned (pre-run)._

**Totals:** 0 🟢 · 53 🟡 · 12 🔴

Legend: 🟢 ready/collected · 🟡 partial/pending · 🔴 gap/external. Targets set from own baseline (deck quartiles are reference-only).

## SDLC register  

_0 🟢 ready/collected · 53 🟡 partial/pending · 12 🔴 gap/external_


### Time-to-Market

| Metric | Status | Reason | What's needed | Owner |
|---|---|---|---|---|
| Lead Time | 🟡 Pending | awaiting first collection |  | DM |
| Requirement Preparation Time | 🟡 Pending | awaiting first collection |  | BA |
| Cycle Time | 🟡 Pending | awaiting first collection |  | DM |
| Development Time | 🟡 Pending | awaiting first collection |  | Dev |
| Testing Time | 🟡 Pending | awaiting first collection |  | QA |
| Deployment Time | 🟡 Pending | awaiting first collection |  | DevOps |

### Role Performance

| Metric | Status | Reason | What's needed | Owner |
|---|---|---|---|---|
| # of Stories Created | 🟡 Pending | awaiting first collection |  | BA |
| Time for Sprint Backlog definition | 🟡 Pending | awaiting first collection |  | BA |
| Quality of Sprint Backlog | 🟡 Pending | awaiting first collection |  | BA |
| Time for Onboarding Material & Glossary | 🟡 Pending | awaiting first collection |  | BA |
| Time for Personas Creation & Definition | 🟡 Pending | awaiting first collection |  | BA |
| Velocity | 🟡 Pending | awaiting first collection |  | Dev |
| Total Story Points Delivered | 🟡 Pending | awaiting first collection |  | Dev |
| Avg Story Points Delivered / Person | 🟡 Pending | awaiting first collection |  | Dev |
| Avg Daily SP Delivered / Person | 🟡 Pending | awaiting first collection |  | Dev |
| Total time spent on Stories (hours) | 🟡 Pending | awaiting first collection |  | Dev |
| Velocity / Person (hours) | 🟡 Pending | awaiting first collection |  | Dev |
| Velocity / Person / Day | 🟡 Pending | awaiting first collection |  | Dev |
| Average Hours / SP | 🟡 Pending | awaiting first collection |  | Dev |
| Average Code Review Time | 🟡 Pending | awaiting first collection |  | Dev |
| Time spent on Code review (total) | 🟡 Pending | awaiting first collection |  | Dev |
| Code review time / day (median) | 🟡 Pending | awaiting first collection |  | Dev |
| Code Review Failure Rate | 🟡 Pending | awaiting first collection |  | Dev |
| Unit Test Coverage | 🟡 Pending | awaiting first collection |  | Dev |
| Technical Debt | 🟡 Pending | awaiting first collection |  | Dev |
| Average Rework Time per Defect | 🟡 Pending | awaiting first collection |  | Dev |
| Avg Time per defect (Non-Prod) | 🟡 Pending | awaiting first collection |  | QA |
| Avg Time per defect (Prod) | 🟡 Pending | awaiting first collection |  | QA |
| Test Development Velocity | 🟡 Pending | awaiting first collection |  | AQA |
| Test Coverage | 🟡 Pending | awaiting first collection |  | QA |
| Test Automation Effort | 🟡 Pending | awaiting first collection |  | AQA |
| Test Effectiveness | 🟡 Pending | awaiting first collection |  | QA |
| Test Result Analysis Effort | 🟡 Pending | awaiting first collection |  | QA |
| Defect Leakage | 🟡 Pending | awaiting first collection |  | QA |
| Defect Leakage (by spent hours) | 🟡 Pending | awaiting first collection |  | QA |
| Total Defects Closed (Non-Prod) | 🟡 Pending | awaiting first collection |  | QA |
| Total Defects Closed (Prod) | 🟡 Pending | awaiting first collection |  | QA |
| Re-work % (Closed Tasks) | 🟡 Pending | awaiting first collection |  | QA |
| Re-work % (All Tasks) | 🟡 Pending | awaiting first collection |  | QA |
| Time on Closed Defects (Non-Prod) | 🟡 Pending | awaiting first collection |  | QA |
| Time on Closed Defects (Prod) | 🟡 Pending | awaiting first collection |  | QA |
| Time on All Defects (Non-Prod) | 🟡 Pending | awaiting first collection |  | QA |
| Total Capacity (FTE) | 🟡 Pending | awaiting first collection |  | DM |
| Total Weekly Capacity (Hours) | 🟡 Pending | awaiting first collection |  | DM |
| # Devs working on Stories | 🟡 Pending | awaiting first collection |  | DM |
| # Devs working on Bugs | 🟡 Pending | awaiting first collection |  | DM |
| Dev Capacity on Stories % | 🟡 Pending | awaiting first collection |  | DM |
| Dev Capacity on Bugs % | 🟡 Pending | awaiting first collection |  | DM |
| Forecast in SPs | 🟡 Pending | awaiting first collection |  | DM |
| Total Velocity (Stories + Defects) / Person / Day | 🟡 Pending | awaiting first collection |  | DM |
| Total Time Spent (Stories + Defects) | 🟡 Pending | awaiting first collection |  | DM |
| Avg Time Spent (Stories)/day/person (actual capacity) | 🟡 Pending | awaiting first collection |  | DM |
| Total Time on All Stories (Non-Prod) | 🟡 Pending | awaiting first collection |  | Dev |

### AI Adoption

| Metric | Status | Reason | What's needed | Owner |
|---|---|---|---|---|
| Engagement Rate | 🔴 External | AI-tool analytics / survey - not in the MCPs | vendor analytics export or survey | All |
| Usage Rate | 🔴 External | AI-tool analytics / survey - not in the MCPs | vendor analytics export or survey | All |
| # of Inactive Users (Last X Days) | 🔴 External | AI-tool analytics / survey - not in the MCPs | vendor analytics export or survey | All |
| Prompts Acceptance Rate | 🔴 External | AI-tool analytics / survey - not in the MCPs | vendor analytics export or survey | Dev |
| Lines of Code Generated | 🔴 External | AI-tool analytics / survey - not in the MCPs | vendor analytics export or survey | Dev |
| % of Chat Users | 🔴 External | AI-tool analytics / survey - not in the MCPs | vendor analytics export or survey | All |
| Self-Proficiency Rate | 🔴 External | AI-tool analytics / survey - not in the MCPs | vendor analytics export or survey | All |
| Performance Rate | 🔴 External | AI-tool analytics / survey - not in the MCPs | vendor analytics export or survey | All |
| Disruption Rate | 🔴 External | AI-tool analytics / survey - not in the MCPs | vendor analytics export or survey | All |
| Time Savings | 🔴 External | AI-tool analytics / survey - not in the MCPs | vendor analytics export or survey | All |
| AI Relevance Score | 🔴 External | AI-tool analytics / survey - not in the MCPs | vendor analytics export or survey | All |
| AI Adaptation Effort | 🔴 External | AI-tool analytics / survey - not in the MCPs | vendor analytics export or survey | All |
