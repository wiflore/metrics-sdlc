# File schemas

All runtime files live in the **user's project** under `.metrics/`. They persist
between runs and are how the plugin reuses prior work. The bundled
`reference/metric-reference.json` is read-only (the tool-agnostic "what to look for").

---

## 1. `.metrics/metric-map.json` — the learned resolution (written by `/metrics-setup`)

Concrete, per-org resolutions so later runs don't re-discover anything.

```jsonc
{
  "resolved_at": "2026-06-25T14:00:00Z",
  "sources": {
    "jira":   { "mcp": "Atlassian", "base": "https://acme.atlassian.net",
                "projects": ["PAY","PLAT"],
                "boards": { "PAY": 12, "PLAT": 19 },
                "fields": {                         // discovered custom-field IDs
                  "story_points": "customfield_10026",
                  "environment":  "customfield_10044",
                  "sprint":       "customfield_10020",
                  "definition_of_ready": "customfield_10101"
                },
                "status_map": {                     // workflow status names actually used
                  "ready_for_dev": ["Ready for Dev","Selected for Development"],
                  "in_progress":   ["In Progress","In Development"],
                  "in_test":       ["In Testing","QA"],
                  "done":          ["Done","Released","Closed"]
                },
                "defect": { "issuetype": "Bug",
                            "prod_signal": { "field": "environment", "prod_values": ["Production","Prod"] } }
              },
    "confluence": { "mcp": "Atlassian", "spaces": ["BA","ENG"],
                    "labels": { "onboarding": "onboarding", "glossary": "glossary",
                                "persona": "persona", "dor": "definition-of-ready" } },
    "bitbucket":  { "mcp": "Bitbucket", "workspace": "acme", "provider": "bitbucket",
                    "repos": ["legacy-payments","legacy-web"] },   // legacy repos -> Bitbucket
    "azure":      { "mcp": "Azure DevOps", "org": "acme", "project": "Core", "provider": "azure",
                    "repos": ["current-platform"],                  // current repo -> Azure DevOps
                    "pipelines": { "deploy_prod": "Release-Prod" } }
  },
  "units": {                                        // ranking dimensions for this org
    "Team":          ["Falcon","Atlas","Core","Edge","Insight","Vision"],
    "Business Unit": ["Payments","Platform","Data & AI"],
    "Persona":       ["BA","Dev","QA","DevOps"],
    "team_to_bu":    { "Falcon":"Payments","Atlas":"Payments","Core":"Platform",
                       "Edge":"Platform","Insight":"Data & AI","Vision":"Data & AI" },
    "team_to_board": { "Falcon": 12, "Atlas": 13 }
  },
  "metrics": {                                      // one entry per reference metric
    "Lead Time": {
      "enabled": true, "source": "jira", "widget": "trend", "unit": "d",
      "goal": "low", "target": 12, "hero": true,
      "collect": "jql:project in (PAY,PLAT) AND resolved >= {since}; read changelog created->Done",
      "rankable": ["Team","Business Unit"]
    },
    "Engagement Rate": {
      "enabled": false, "source": "external",
      "reason": "AI tool analytics (Copilot/Cursor/Claude Code) — not in connected MCPs",
      "widget": "gauge", "unit": "%", "goal": "high", "target": 75
    }
    // ... all 65 metrics
  }
}
```

Rules:
- `enabled:false` for any metric whose source can't be resolved (always true for the 12
  `external` rows). Record `reason`. Never silently fabricate values for these.
- `target`/`goal`/`hero` are editable by the user; keep their edits across re-discovery
  (merge, don't overwrite confirmed values).

---

## 2. `.metrics/state.json` — incremental watermarks (updated by `/metrics-collect`)

```jsonc
{
  "runs": [ { "at": "2026-06-25T14:10:00Z", "mode": "full",        "metrics": 53 },
            { "at": "2026-07-09T14:05:00Z", "mode": "incremental", "metrics": 53 } ],
  "watermarks": {                 // last successfully collected point per source
    "jira":      "2026-07-09T14:05:00Z",
    "bitbucket": "2026-07-09T14:05:00Z",
    "azure":     "2026-07-09T14:05:00Z",
    "confluence":"2026-07-09T14:05:00Z"
  },
  "last_sprint": "PAY Sprint 48"
}
```

Incremental rule: query each source only for items `updated >= watermark[source]`
(use `{since}` in the `collect` string). Point-in-time metrics (coverage, capacity,
tech debt) are simply re-fetched at their latest value.

---

## 3. `.metrics/<set>/metrics-data.json` — the dashboard data (consumed by `build_dashboard.py --set`)

This is exactly the shape the HTML template expects on `window.__METRICS__`.

```jsonc
{
  "generated_at": "2026-07-09T14:06:00Z",
  "period_label": "Sample data · sprint ending 9 Jul 2026",
  "metrics": [
    { "name":"Lead Time", "cat":"Time-to-Market", "group":"Cycle Time",
      "owner":"DM", "stage":"Cross-stage", "level":"Headline",
      "present":"trend", "unit":"d", "value":14.2, "target":12, "goal":"low",
      "delta":-8, "series":[18,17.4,16.9,16,15.5,15.1,14.6,14.2],
      "formula":"delivered − requested", "hero":true }
    // present ∈ kpi | trend | gauge | bar | stacked
    // gauge/kpi need value,target,goal,delta ; trend needs series[] ;
    // bar needs bars:[{l,v}] ; stacked needs seg:[{l,v,c}]
  ],
  "rankings": {
    "Team": {
      "units": ["Falcon","Atlas","Core","Edge","Insight","Vision"],
      "metrics": [
        { "name":"Velocity","unit":"SP","goal":"high","target":135,"cat":"Role Performance",
          "values": { "Falcon":{"v":148,"delta":6}, "Atlas":{"v":141,"delta":2} /* ... */ } }
      ]
    },
    "Business Unit": { "units":[...], "metrics":[...] },
    "Persona":       { "units":[...], "metrics":[...] }
  },
  "history": {                    // optional; append each run to build trends over time
    "Lead Time": [ {"sprint":"PAY 47","value":15.1}, {"sprint":"PAY 48","value":14.2} ]
  }
}
```

The `series` for a `trend` metric is normally built from `history` (one point per sprint).
On the first run there may be only 1–2 points; trends fill in as runs accumulate.

---

## 4. Reference sets (bundled, read-only) — kept separate by requirement

Two files, each tagged with `set` / `set_id`, updated independently:

- `reference/metric-reference.json` — `set_id: sdlc-register` (the original SDLC metrics).
- `reference/northstar-reference.json` — `set_id: northstar-plandek` (the sponsor
  four-pillar framework + AI overlay; carries `pillar`, `status`, `access_item`,
  `benchmark_ai_top`, `in_our_solution`).

Carry the `set` tag through `metrics-data.json` (add `"set"` per metric) and the
dashboard so the two requirements stay distinguishable. Regenerate both with
`scripts/xlsx_to_reference.py <workbook.xlsx>`.

## 5. `.metrics/<set>/coverage-report.md` — the gap report (written every run, per set)

Produced by `scripts/build_coverage_report.py` (the reviewer owns it at checkpoint E).
Mirrors the sponsor's alignment doc: grouped by **set → pillar/category**, one row per
metric with 🟢/🟡/🔴 status, the reason, **what's needed** (A–I access/definition item,
vendor export, or mapping fix), and owner. Runs before any collection (a "planned"
report from the references) and after (real status from the run artifacts).

---

## 6. Folder layout (per-set separation)

The two reports are kept separate on disk so each can be generated independently:

```
.metrics/
  metric-map.json            shared — learned resolution, every entry tagged "set"; repos carry "provider" (bitbucket|azure)
  state.json                 shared — per-set incremental watermarks
  DISCOVERY.md               shared — what discovery resolved/assumed/left unmapped
  sdlc/                      SDLC register report
    partials/<source>.json
    metrics-data.json
    validation-report.json
    coverage-report.md
    review.md
  northstar/                 Northstar (Plandek) report
    partials/<source>.json
    metrics-data.json
    validation-report.json
    coverage-report.md
    review.md
dashboards/
  dashboard-sdlc.html
  dashboard-northstar.html
```

Build either or both with `build_dashboard.py --set sdlc|northstar|both` and
`build_coverage_report.py --set sdlc|northstar|both`. The bundled reference is likewise two
files (`metric-reference.json`, `northstar-reference.json`), updated independently.
