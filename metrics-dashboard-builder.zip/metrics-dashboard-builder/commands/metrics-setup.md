---
description: First-run discovery (covers both report sets) — learn where each metric lives and write .metrics/metric-map.json
argument-hint: "[--reset]"
---

Run **discovery** for the metrics dashboard. This teaches the plugin the concrete
fields and conventions of *this* organization so future collections are fast and correct.

Use the **metric-collection** skill. Steps:

1. Read **both** reference sets — `reference/metric-reference.json` (SDLC register, 65) and
   `reference/northstar-reference.json` (Northstar/Plandek, 22) — and `reference/schemas.md`.
   One shared map covers both sets; tag every entry with its `set` so each report can be
   built independently later.
2. If `.metrics/metric-map.json` already exists and `--reset` was **not** passed, load it
   and only fill gaps / re-confirm items marked uncertain. With `--reset`, rebuild it but
   preserve any user-set `target`, `goal`, and `hero` values.
3. Probe the connected MCPs (Atlassian for Jira + Confluence, Bitbucket, Azure DevOps),
   source by source, to resolve:
   - Jira: projects, boards, the **story-points / sprint / environment / Definition-of-Ready
     custom-field IDs**, the **status workflow names** (for changelog durations), and how
     **prod vs non-prod defects** are flagged.
   - Confluence: spaces and the **labels** for onboarding / glossary / persona / DoR pages.
   - Repos: workspace/org, project, and repos in scope, tagging each repo with its
     **`provider`** — `bitbucket` for **legacy** repos, `azure` for the **current** repo.
   - Pipelines: the release pipeline(s) and production environment name.
   - Ranking units: Teams, Business Units, the team→BU map, and team→board/repo.
4. **Ask one grouped question** whenever a choice is genuinely ambiguous (e.g. which of two
   fields is story points, which label means prod). Record the answers. Do not guess.
5. Mark `external` metrics (AI-tool analytics, surveys) `enabled:false` with a reason (these
   exist in both sets and are not in the four MCPs).
6. Write `.metrics/metric-map.json` and a human-readable `.metrics/DISCOVERY.md`
   (what was resolved, assumed, and left unmapped — with the exact IDs/labels).

End with a short summary **per set**: how many metrics are mapped, how many need a human
decision, and how many are external/disabled. Suggest running `/metrics-collect [sdlc|northstar|both]` next.
