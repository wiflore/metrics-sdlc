---
description: Full multi-agent pipeline — collect, validate, consolidate, build, review (per set, gated)
argument-hint: "[sdlc|northstar|both] [--full] [--reset]"
---

Run the end-to-end pipeline using the **orchestration** skill. You are the orchestrator;
delegate to subagents and enforce a checkpoint between phases. The two requirement sets
(`sdlc`, `northstar`) are independent reports — run one, the other, or both (default `both`).
Discovery and the learned map are shared; collection, consolidation, build and review are per set.

0. **Preflight** — confirm the Atlassian, Bitbucket and Azure DevOps MCPs are connected and
   that `.metrics/metric-map.json` exists. If it doesn't (or `--reset`), run **Discovery**
   (the `/metrics-setup` flow), which resolves metrics for both sets and tags each entry with
   its `set` and (for repos) its `provider` (Bitbucket for legacy repos, Azure DevOps for the
   current repo) → **Checkpoint A**: show the resolved map and wait for confirmation.

For each selected set (write everything under `.metrics/<set>/`):

1. **Collect (parallel)** — launch `jira-collector`, `confluence-collector`, `vcs-collector`
   and `pipeline-collector` in one batch, each scoped to that set's `enabled` metrics with the
   `{since}` watermark from `state.json`. Each writes `.metrics/<set>/partials/<source>.json`.
   → **Checkpoint B (coverage)**: every source returned; on error keep prior values + mark
   stale and ask before a partial refresh.
2. **Validate** — `metrics-validator` → `.metrics/<set>/validation-report.json`.
   → **Checkpoint C**: no critical findings.
3. **Consolidate** — `metrics-consolidator` → `.metrics/<set>/metrics-data.json` (+history,
   deltas, rankings) and updated `state.json`.
   → **Checkpoint D (integrity)**: schema-valid; every enabled metric present.
4. **Build** — `python3 ${CLAUDE_PLUGIN_ROOT}/scripts/build_dashboard.py --set <set>`
   and `python3 ${CLAUDE_PLUGIN_ROOT}/scripts/build_coverage_report.py --set <set>`.
5. **Review** — `metrics-reviewer` → `.metrics/<set>/review.md`.
   → **Checkpoint E (sign-off)**: present the reviewer summary + `.metrics/<set>/coverage-report.md`.

Pass `--full` to rebuild rather than increment. Never push past a failed gate silently and
never fabricate values. End with one summary per set: counts (collected/unchanged/stale/
skipped/failed), each gate's result, and the `dashboards/dashboard-<set>.html` path.
