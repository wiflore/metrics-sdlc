---
description: Render the self-contained HTML dashboard(s) — SDLC, Northstar, or both
argument-hint: "[sdlc|northstar|both] (default both)"
---

Render the report dashboard(s). The two requirement sets are separate reports, each with
its own template, data folder, and output file.

1. Decide the target set from the argument (`sdlc`, `northstar`, or `both`; default `both`).
2. For each target, confirm `.metrics/<set>/metrics-data.json` exists. If not, tell the user
   to run `/metrics-collect <set>` first (the dashboard will otherwise fall back to sample data).
3. Run the build script:

   ```
   python3 ${CLAUDE_PLUGIN_ROOT}/scripts/build_dashboard.py --set ${1:-both}
   ```

   It injects each set's data into the matching template
   (`assets/dashboard-sdlc.template.html` / `assets/dashboard-northstar.template.html`) and
   writes `dashboards/dashboard-<set>.html` — self-contained, inline SVG charts, no external deps.
4. Report each output path and a one-line summary. Every dashboard has three tabs —
   **Overview** (KPI strip + sections), **Rankings** (league tables), and **Coverage**
   (the what's-missing view, scoped to that set).
