---
description: Collect metrics from the connected MCPs (incremental) into .metrics/<set>/metrics-data.json
argument-hint: "[sdlc|northstar|both] [--full] [--since YYYY-MM-DD] [--only <metric|category>]"
---

Collect metric values using the **metric-collection** skill, for the chosen requirement set(s)
(`sdlc`, `northstar`, or `both`; default `both`). Each set is collected independently and
written under its own folder `.metrics/<set>/`.

1. If `.metrics/metric-map.json` does **not** exist, stop and tell the user to run
   `/metrics-setup` first (collecting without the map would guess field IDs).
2. Load `.metrics/metric-map.json` (shared; each metric tagged with `set`), `.metrics/state.json`,
   and the existing `.metrics/<set>/metrics-data.json` (if any).
3. For each selected set, restrict to that set's `enabled` metrics. Determine the window:
   - default **incremental** — items changed since `state.watermarks[<set>][source]`,
   - `--full` re-collect everything, `--since DATE` from a date, `--only` one metric/category.
4. For each enabled metric, run its `collect` recipe (substituting `{since}`), compute the
   value per the reference `derivation`, and merge into `.metrics/<set>/metrics-data.json`
   (current value/delta; append to `history`; recompute per-unit `rankings`). For VCS metrics,
   query the right provider per repo — **Bitbucket** for legacy repos, **Azure DevOps** for the
   current repo (the repo's `provider` is recorded in the map).
5. Leave `external`/disabled metrics out (don't fabricate). On a source error keep prior values
   and mark them stale — never zero them.
6. Update `state.json` (per-set watermarks + run record) and write `.metrics/<set>/metrics-data.json`.

Delegate per-source collection to the source subagents in parallel — `jira-collector`,
`confluence-collector`, `vcs-collector`, `pipeline-collector` — writing
`.metrics/<set>/partials/<source>.json`, then run `metrics-validator` (checkpoint C) and
`metrics-consolidator`. For the full gated pipeline use `/metrics-refresh`.

End with, per set: collected / unchanged / skipped (external) / failed counts, the period label,
and a reminder to run `/metrics-dashboard <set>`.
