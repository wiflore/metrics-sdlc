# metrics-dashboard-builder

A Claude Code plugin that builds the **SDLC Metrics Dashboard** from your delivery
tools. It collects metrics from **Jira, Confluence, Bitbucket and Azure DevOps**
(via their MCP connectors) and renders a self-contained HTML dashboard.

It is **self-improving and incremental**:
- **First run** discovers where each metric actually lives in your org (the real
  custom-field IDs, status names, boards, repos, pipelines, labels) and saves that as
  a reusable map.
- **Later runs** read the map and pull only what changed since the last run, merging
  into the existing data so trends and rankings build up over time.

## Install

```
claude --plugin-dir ./metrics-dashboard-builder        # load for one session
# or add to a marketplace and: /plugin install metrics-dashboard-builder@<marketplace>
```

Requires the **Atlassian** (Jira + Confluence), **Bitbucket**, and **Azure DevOps**
MCP connectors to be connected, and `python3` with `openpyxl` (only for regenerating
the reference). Reading-only — the plugin never modifies your source systems.

## Commands

| Command | What it does |
|---|---|
| `/metrics-setup` | First-run discovery → writes `.metrics/metric-map.json` + `DISCOVERY.md` |
| `/metrics-collect [sdlc\|northstar\|both]` | Incremental pull from the MCPs → updates `.metrics/<set>/metrics-data.json` |
| `/metrics-dashboard [sdlc\|northstar\|both]` | Renders `dashboards/dashboard-<set>.html` from the collected data |
| `/metrics-refresh [sdlc\|northstar\|both]` | Full gated pipeline (collect → validate → consolidate → build → review) per set |

**VCS sources:** Bitbucket for legacy repos, Azure DevOps for the current repo — the
learned map tags each repo with its `provider` and the collector queries the right MCP.

Typical flow: `/metrics-setup` once (covers both sets), then `/metrics-refresh` each sprint
(run `both`, or just `northstar` / `sdlc`). The two reports — SDLC register and Northstar
(Plandek) — are generated independently, each with Overview · Rankings · Coverage tabs.

## How it works

```
reference/*.json                  what to look for      (bundled, two tagged sets)
   ├─ metric-reference.json       SDLC register (65)
   └─ northstar-reference.json    Northstar / Plandek (22)
              │  /metrics-setup  (discovery, learns the org)
              ▼
.metrics/metric-map.json          concrete resolution   (per project, shared; tagged by set, repos carry provider)
              │  /metrics-collect [sdlc|northstar|both]  (incremental, uses watermarks)
              ▼
.metrics/<set>/metrics-data.json  dashboard data + history   (per set)
              │  /metrics-dashboard [set]  (build_dashboard.py --set injects into that set's template)
              ▼
dashboards/dashboard-<set>.html + .metrics/<set>/coverage-report.md   per-set dashboard + gap report
```

### Multi-agent pipeline (`/metrics-refresh`)

The main session is the **orchestrator**; it delegates to specialized subagents and enforces
a checkpoint between each phase (subagents can't nest, so orchestration stays in the main thread):

```
[Preflight] → [Discovery] —A→ [Collect ‖] —B→ [Validate] —C→ [Consolidate] —D→ [Build] → [Review] —E→ done

 Collect ‖ : jira-collector · confluence-collector · vcs-collector · pipeline-collector  (parallel)
 Validate  : metrics-validator   (formulas vs data, units, ranges, denominators)
 Consolidate: metrics-consolidator (merge + history + deltas + rankings → metrics-data.json)
 Review    : metrics-reviewer     (plausibility, movements, stale/disabled coverage)

 Checkpoints (gates, not agents):
 A map confirmed (human) · B coverage · C validation · D integrity · E sign-off (human)
```

Checkpoints are gates the orchestrator enforces, not subagents — a failed gate stops the
pipeline with a specific report; values are never fabricated to pass one.

## Layout

```
metrics-dashboard-builder/
├── .claude-plugin/plugin.json
├── commands/            metrics-setup · metrics-collect · metrics-dashboard · metrics-refresh
├── skills/
│   ├── metric-collection/   SKILL.md + reference (metric-reference.json, schemas.md, workbook)
│   └── orchestration/       SKILL.md — the pipeline + checkpoints (run by /metrics-refresh)
├── agents/              jira-collector · confluence-collector · vcs-collector · pipeline-collector
│                        metrics-validator · metrics-consolidator · metrics-reviewer
├── assets/                two templates: dashboard-sdlc · dashboard-northstar (data-injection marker)
├── samples/              ready-to-open reports (2 dashboards + 2 workbooks, sample data)
└── scripts/
    ├── build_dashboard.py        injects per-set data → dashboards/dashboard-<set>.html  (--set sdlc|northstar|both)
    ├── build_coverage_report.py  per-metric gap report (both sets) → coverage-report.md
    └── xlsx_to_reference.py       regenerate BOTH reference sets from the workbook
```

### Agents

| Agent | Role |
|---|---|
| `jira-collector` | issues, sprints, worklogs, changelog → durations, counts, ratios |
| `confluence-collector` | BA artifacts by label (onboarding, glossary, persona, DoR) |
| `vcs-collector` | Bitbucket / Azure Repos pull requests → review time, failure rate |
| `pipeline-collector` | Azure / Bitbucket Pipelines → deployment time, CI coverage |
| `metrics-validator` | formulas vs data, units, ranges, denominators (checkpoint C) |
| `metrics-consolidator` | merge partials + prior run → metrics-data.json (history, deltas, rankings) |
| `metrics-reviewer` | final plausibility / movements / coverage sign-off (checkpoint E) |

The **orchestrator is the main session** (not an agent) and **checkpoints are gates**, not agents.

## Notes

- The **12 AI-adoption metrics** (engagement, acceptance, time savings, …) come from the
  AI tools' own analytics (Copilot / Cursor / Claude Code) and surveys, **not** from the
  four MCPs. They are mapped but `enabled:false`; paste an export to populate them.
- The dashboard renders with built-in **sample data** until you collect real data, so you
  can preview it immediately.
- To change the metric set, edit the workbook's *Metrics* and *Agent Reference* tabs and
  run `scripts/xlsx_to_reference.py`.
